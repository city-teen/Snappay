import { type FormEvent, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  getGetPaysnapEditSessionQueryKey,
  getGetPaysnapRatesQueryKey,
  useGetPaysnapEditSession,
  useGetPaysnapRates,
  useLockPaysnapEditSession,
  useUpdatePaysnapRates,
  useUnlockPaysnapEditSession,
} from '@workspace/api-client-react';
import { ArrowDown, ArrowRightLeft, Check, Clock3, LockKeyhole, Pencil, RotateCcw, ShieldCheck, WalletCards } from 'lucide-react';

const STORAGE_KEY = 'paysnap-reference-rates-v1';
const MINIMUM_INR_AMOUNT = 25_000;
const PUBLIC_APP_URL = 'https://pay-snap-currency-converter--metadubai.replit.app';

function readSavedRates() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return { aedRate: '', inrRate: '' };
    const parsed = JSON.parse(saved) as { aedRate?: unknown; inrRate?: unknown };
    return {
      aedRate: typeof parsed.aedRate === 'string' ? parsed.aedRate : '',
      inrRate: typeof parsed.inrRate === 'string' ? parsed.inrRate : '',
    };
  } catch {
    return { aedRate: '', inrRate: '' };
  }
}

function numericValue(value: string) {
  if (!value.trim()) return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function formatIndian(number: number, digits = 2) {
  return new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: digits,
  }).format(number);
}

function formatReferenceRate(value: number | null | undefined) {
  if (value == null) return '';
  return new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 8,
    useGrouping: false,
  }).format(value);
}

function CountryFlag({ country }: { country: 'uae' | 'india' }) {
  if (country === 'uae') {
    return (
      <svg className="country-flag" viewBox="0 0 30 20" role="img" aria-label="United Arab Emirates flag">
        <rect x="0" y="0" width="8" height="20" fill="#ef3340" />
        <rect x="8" y="0" width="22" height="6.67" fill="#009739" />
        <rect x="8" y="6.67" width="22" height="6.66" fill="#fff" />
        <rect x="8" y="13.33" width="22" height="6.67" fill="#111" />
      </svg>
    );
  }

  return (
    <svg className="country-flag" viewBox="0 0 30 20" role="img" aria-label="India flag">
      <rect x="0" y="0" width="30" height="6.67" fill="#ff9933" />
      <rect x="0" y="6.67" width="30" height="6.66" fill="#fff" />
      <rect x="0" y="13.33" width="30" height="6.67" fill="#138808" />
      <circle cx="15" cy="10" r="2.35" fill="none" stroke="#000080" strokeWidth=".7" />
      <circle cx="15" cy="10" r=".55" fill="#000080" />
    </svg>
  );
}

function getErrorStatus(error: unknown): number | null {
  if (error && typeof error === 'object' && 'status' in error) {
    const status = (error as { status?: unknown }).status;
    return typeof status === 'number' ? status : null;
  }
  return null;
}

function Home() {
  const queryClient = useQueryClient();
  const isPreviewEnvironment =
    typeof window !== 'undefined' &&
    (window.location.hostname.endsWith('.replit.dev') ||
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1');
  const sharedRatesQuery = useGetPaysnapRates({
    query: {
      queryKey: getGetPaysnapRatesQueryKey(),
      refetchInterval: 10_000,
    },
  });
  const editSessionQuery = useGetPaysnapEditSession({
    query: {
      queryKey: getGetPaysnapEditSessionQueryKey(),
      refetchInterval: 30_000,
    },
  });
  const unlockMutation = useUnlockPaysnapEditSession();
  const lockMutation = useLockPaysnapEditSession();
  const saveRatesMutation = useUpdatePaysnapRates();
  const [legacyRates] = useState(readSavedRates);
  const [rates, setRates] = useState({ aedRate: '', inrRate: '' });
  const [ratesDirty, setRatesDirty] = useState(false);
  const [ratesSaved, setRatesSaved] = useState(false);
  const [amount, setAmount] = useState('');
  const [ratePassword, setRatePassword] = useState('');
  const [showUnlockForm, setShowUnlockForm] = useState(false);
  const isEditingRates = editSessionQuery.data?.unlocked === true;
  const sharedRateValues = {
    aedRate: formatReferenceRate(sharedRatesQuery.data?.aedRate),
    inrRate: formatReferenceRate(sharedRatesQuery.data?.inrRate),
  };
  const visibleRates = isEditingRates ? rates : sharedRateValues;
  const today = useMemo(
    () => new Intl.DateTimeFormat('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }).format(new Date()),
    [],
  );

  useEffect(() => {
    const shared = sharedRatesQuery.data;
    if (!shared || (ratesDirty && isEditingRates)) return;

    if (
      shared.updatedAt === null &&
      isEditingRates &&
      (legacyRates.aedRate || legacyRates.inrRate)
    ) {
      setRates(legacyRates);
      setRatesDirty(true);
      return;
    }

    setRates({
      aedRate: formatReferenceRate(shared.aedRate),
      inrRate: formatReferenceRate(shared.inrRate),
    });
    setRatesDirty(false);
  }, [sharedRatesQuery.data, isEditingRates, ratesDirty, legacyRates]);

  const aed = numericValue(visibleRates.aedRate);
  const inr = numericValue(visibleRates.inrRate);
  const amountValue = numericValue(amount);
  const aedError = rates.aedRate && (aed === null || aed <= 0);
  const inrError = rates.inrRate && (inr === null || inr <= 0);
  const amountError = amount && (amountValue === null || amountValue < 0);
  const ratio = aed !== null && aed > 0 && inr !== null && inr > 0 ? inr / aed : null;
  const ready = ratio !== null;
  const canConvert = ready && amountValue !== null && amountValue >= 0 && !aedError && !inrError;
  const estimatedInr = canConvert ? (amountValue as number) * (ratio as number) : null;
  const belowMinimum = estimatedInr !== null && estimatedInr <= MINIMUM_INR_AMOUNT;
  const converted = estimatedInr !== null && !belowMinimum ? estimatedInr : null;

  const updateRate = (key: 'aedRate' | 'inrRate', value: string) => {
    setRates((current) => ({ ...current, [key]: value }));
    setRatesDirty(true);
    setRatesSaved(false);
    saveRatesMutation.reset();
  };

  const clearRates = () => {
    setRates({ aedRate: '', inrRate: '' });
    setRatesDirty(true);
    setRatesSaved(false);
    saveRatesMutation.reset();
  };

  const saveRates = () => {
    if (aedError || inrError || !ratesDirty || saveRatesMutation.isPending) return;

    saveRatesMutation.mutate(
      {
        data: {
          aedRate: numericValue(rates.aedRate),
          inrRate: numericValue(rates.inrRate),
        },
      },
      {
        onSuccess: (saved) => {
          queryClient.setQueryData(getGetPaysnapRatesQueryKey(), saved);
          const savedValues = {
            aedRate: formatReferenceRate(saved.aedRate),
            inrRate: formatReferenceRate(saved.inrRate),
          };
          setRates(savedValues);
          setRatesDirty(false);
          setRatesSaved(true);
          try {
            if (!savedValues.aedRate && !savedValues.inrRate) {
              localStorage.removeItem(STORAGE_KEY);
            } else {
              localStorage.setItem(STORAGE_KEY, JSON.stringify(savedValues));
            }
          } catch {
            // Shared rates are saved on the server even if local storage is unavailable.
          }
        },
        onError: (error) => {
          if (getErrorStatus(error) === 401) {
            void queryClient.invalidateQueries({
              queryKey: getGetPaysnapEditSessionQueryKey(),
            });
          }
        },
      },
    );
  };

  const handleUnlock = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!ratePassword.trim() || unlockMutation.isPending) return;

    unlockMutation.mutate(
      { data: { password: ratePassword } },
      {
        onSuccess: (session) => {
          queryClient.setQueryData(getGetPaysnapEditSessionQueryKey(), session);
          setRatePassword('');
          setShowUnlockForm(false);
        },
      },
    );
  };

  const handleLock = () => {
    lockMutation.mutate(undefined, {
      onSuccess: (session) => {
        queryClient.setQueryData(getGetPaysnapEditSessionQueryKey(), session);
        setRatePassword('');
        setShowUnlockForm(false);
      },
    });
  };

  const unlockErrorMessage = unlockMutation.isError
    ? getErrorStatus(unlockMutation.error) === 401
      ? 'Password തെറ്റാണ്. വീണ്ടും ശ്രമിക്കൂ.'
      : 'Unlock ചെയ്യാനായില്ല. വീണ്ടും ശ്രമിക്കൂ.'
    : '';

  const resultMessage = amountError
    ? 'Enter a valid amount of 0 or more.'
    : sharedRatesQuery.isError
      ? 'Shared rates could not be loaded. Refresh and try again.'
      : !ready
      ? 'Add both reference rates to see your conversion.'
      : !amount
        ? 'Enter an AED amount to get started.'
        : belowMinimum
          ? 'ഈ തുക ₹25,000-ന് താഴെയാണ്. ₹25,000-ന് മുകളിലുള്ള തുകയ്ക്ക് മാത്രമാണ് ഈ നിരക്ക് ബാധകം.'
        : 'Calculated from the reference rates you entered.';

  return (
    <div className="app-shell">
      <header className="topbar">
        <a href="/" className="brand" aria-label="PaySnap home" data-testid="link-paysnap-home">
          <span className="brand-mark"><WalletCards size={20} strokeWidth={2.2} /></span>
          <span className="brand-word">PaySnap</span>
        </a>
        <div className="top-note" data-testid="text-manual-rate-notice">
          <Clock3 size={16} strokeWidth={1.8} />
          Your rate, your reference
        </div>
      </header>

      {isPreviewEnvironment && (
        <aside className="preview-rate-warning" role="note" data-testid="preview-rate-warning">
          <div>
            <strong>ഇത് Preview പതിപ്പാണ്.</strong>
            <p>ഇവിടെ സേവ് ചെയ്യുന്ന നിരക്ക് സുഹൃത്തുക്കൾക്ക് കാണില്ല. എല്ലാവർക്കും കാണിക്കാൻ Public PaySnap-ൽ നിരക്ക് സേവ് ചെയ്യുക.</p>
          </div>
          <a href={PUBLIC_APP_URL} target="_blank" rel="noreferrer" data-testid="link-public-paysnap">
            Public PaySnap തുറക്കുക
          </a>
        </aside>
      )}

      <main className="main-content">
        <section className="intro" aria-labelledby="page-title">
          <div className="eyebrow">A simpler way to send</div>
          <h1 id="page-title">Know what arrives.</h1>
          <p>See the shared AED-to-INR rate and calculate your amount in a moment.</p>
        </section>

        <section className="workspace" aria-label="AED to INR converter">
          <div className="rate-board">
            <div className="board-head">
              <div>
                <div className="board-kicker">
                  {isPreviewEnvironment ? 'Preview rates · Not public' : 'Live shared rates'}
                </div>
                <h2>Today’s Rate</h2>
              </div>
              <div className="date-chip" data-testid="text-todays-date">
                {today}
                <span>Today</span>
              </div>
            </div>

            <div className="board-body">
              <p className="manual-flag" data-testid="status-manual-rates">
                <span className="manual-dot" />
                {sharedRatesQuery.isLoading
                  ? 'Loading shared rates…'
                  : sharedRatesQuery.isError
                    ? 'Shared rates are unavailable right now.'
                    : sharedRatesQuery.data?.updatedAt === null
                      ? 'No shared rate has been published yet.'
                      : isPreviewEnvironment
                        ? 'Preview rate · Not visible to public users'
                        : 'Manually entered · Shared with everyone'}
              </p>

              <div className="rate-fields">
                <div>
                  <label className="field-label" htmlFor="aed-reference">
                    <span><span className="currency-inline"><CountryFlag country="uae" /> AED</span> reference rate</span>
                    <small>ദിർഹം</small>
                  </label>
                  <div className="rate-input-wrap">
                    <span className="currency-prefix"><CountryFlag country="uae" /> AED</span>
                    <input
                      id="aed-reference"
                      className="rate-input"
                      type="text"
                      inputMode="decimal"
                      placeholder="Enter rate"
                      value={visibleRates.aedRate}
                      disabled={!isEditingRates || !sharedRatesQuery.data || saveRatesMutation.isPending}
                      onChange={(event) => updateRate('aedRate', event.target.value)}
                      aria-invalid={Boolean(aedError)}
                      aria-describedby="aed-rate-error"
                      data-testid="input-aed-reference-rate"
                    />
                  </div>
                  <p className="field-error" id="aed-rate-error" data-testid="text-aed-rate-error" aria-live="polite">
                    {aedError ? 'Rate must be greater than zero.' : ''}
                  </p>
                </div>

                <div>
                  <label className="field-label" htmlFor="inr-reference">
                    <span><span className="currency-inline"><CountryFlag country="india" /> INR</span> reference rate</span>
                    <small>രൂപ</small>
                  </label>
                  <div className="rate-input-wrap">
                    <span className="currency-prefix"><CountryFlag country="india" /> INR</span>
                    <input
                      id="inr-reference"
                      className="rate-input"
                      type="text"
                      inputMode="decimal"
                      placeholder="Enter rate"
                      value={visibleRates.inrRate}
                      disabled={!isEditingRates || !sharedRatesQuery.data || saveRatesMutation.isPending}
                      onChange={(event) => updateRate('inrRate', event.target.value)}
                      aria-invalid={Boolean(inrError)}
                      aria-describedby="inr-rate-error"
                      data-testid="input-inr-reference-rate"
                    />
                  </div>
                  <p className="field-error" id="inr-rate-error" data-testid="text-inr-rate-error" aria-live="polite">
                    {inrError ? 'Rate must be greater than zero.' : ''}
                  </p>
                </div>
              </div>

              <div className="rate-threshold-note" data-testid="text-rate-threshold">
                <ShieldCheck size={15} aria-hidden="true" />
                <span>₹25,000-ന് മുകളിലുള്ള തുകയ്ക്ക് മാത്രം ഈ നിരക്ക് ബാധകം.</span>
              </div>

              <div className="board-rule" />
              <div className="board-foot">
                <div className="formula" data-testid="text-conversion-formula">
                  <ArrowRightLeft size={14} />
                  <span className="formula-currencies"><CountryFlag country="india" /> INR per <CountryFlag country="uae" /> AED</span>
                  <strong>INR rate ÷ AED rate</strong>
                </div>
                <div className="board-actions">
                  {editSessionQuery.isLoading ? (
                    <span className="lock-state" role="status">Checking lock…</span>
                  ) : isEditingRates ? (
                    <>
                      <button type="button" className="save-rates-button" onClick={saveRates} disabled={!ratesDirty || !sharedRatesQuery.data || Boolean(aedError) || Boolean(inrError) || saveRatesMutation.isPending || lockMutation.isPending} data-testid="button-save-shared-rates">
                        {saveRatesMutation.isPending
                          ? 'Saving…'
                          : isPreviewEnvironment
                            ? 'Save to preview'
                            : 'Publish rate for everyone'}
                      </button>
                      <button type="button" className="edit-rate-button" onClick={handleLock} disabled={lockMutation.isPending || saveRatesMutation.isPending} data-testid="button-lock-rates">
                        <LockKeyhole size={13} />
                        {lockMutation.isPending ? 'Locking…' : 'Lock rates'}
                      </button>
                      <button type="button" className="reset-button" onClick={clearRates} disabled={lockMutation.isPending || saveRatesMutation.isPending} data-testid="button-reset-rates">
                        <RotateCcw size={13} />
                        Reset rates
                      </button>
                    </>
                  ) : (
                    <button type="button" className="edit-rate-button" onClick={() => { setShowUnlockForm(true); unlockMutation.reset(); }} data-testid="button-edit-rates">
                      <Pencil size={13} />
                      Edit rates
                    </button>
                  )}
                </div>
              </div>
              {isEditingRates && ratesDirty && <p className="rate-save-feedback" role="status" data-testid="text-unsaved-rates">Changes are only on this screen until you save.</p>}
              {ratesSaved && (
                <p className="rate-save-feedback rate-save-success" role="status" data-testid="text-shared-rates-saved">
                  {isPreviewEnvironment
                    ? 'Preview-ൽ മാത്രം സേവ് ചെയ്തു. എല്ലാവർക്കും കാണിക്കാൻ Public PaySnap-ൽ സേവ് ചെയ്യുക.'
                    : 'Rate published. Everyone can see it now.'}
                </p>
              )}
              {saveRatesMutation.isError && <p className="unlock-error" role="alert" data-testid="text-save-rates-error">{getErrorStatus(saveRatesMutation.error) === 401 ? 'Your edit session expired. Unlock rates again before saving.' : 'Shared rates could not be saved. Please try again.'}</p>}
              {showUnlockForm && !isEditingRates && (
                <form className="unlock-form" onSubmit={handleUnlock} data-testid="form-unlock-rates">
                  <label htmlFor="paysnap-edit-password">Rates password</label>
                  <div className="unlock-form-row">
                    <input
                      id="paysnap-edit-password"
                      type="password"
                      autoComplete="current-password"
                      value={ratePassword}
                      onChange={(event) => setRatePassword(event.target.value)}
                      placeholder="Enter password"
                      required
                      disabled={unlockMutation.isPending}
                      data-testid="input-rate-edit-password"
                    />
                    <button type="submit" className="unlock-submit" disabled={unlockMutation.isPending || !ratePassword.trim()} data-testid="button-unlock-rates">
                      {unlockMutation.isPending ? 'Checking…' : 'Unlock'}
                    </button>
                    <button type="button" className="unlock-cancel" onClick={() => { setShowUnlockForm(false); setRatePassword(''); unlockMutation.reset(); }} disabled={unlockMutation.isPending} data-testid="button-cancel-unlock">
                      Cancel
                    </button>
                  </div>
                  {unlockErrorMessage && <p className="unlock-error" role="alert" data-testid="text-unlock-error">{unlockErrorMessage}</p>}
                </form>
              )}
              {lockMutation.isError && <p className="unlock-error" role="alert" data-testid="text-lock-error">Lock ചെയ്യാനായില്ല. വീണ്ടും ശ്രമിക്കൂ.</p>}
            </div>
          </div>

          <div className="convert-card">
            <div className="snap-pay-brand" data-testid="text-paysnap-brand">
              <div className="snap-pay-identity">
                <span className="snap-pay-mark"><WalletCards size={17} strokeWidth={2.2} /></span>
                <span className="snap-pay-copy">
                  <strong>PaySnap</strong>
                  <small>Fast &amp; Trust</small>
                </span>
              </div>
              <div className="conversion-rate" data-testid="text-effective-rate">
                <ArrowDown size={12} aria-hidden="true" />
                {ratio !== null
                  ? <><span className="currency-inline">1 <CountryFlag country="uae" /> AED =</span><strong className="currency-inline"><CountryFlag country="india" /> ₹{formatIndian(ratio, 4)}</strong></>
                  : sharedRatesQuery.isLoading
                    ? <span>Loading shared rates…</span>
                    : sharedRatesQuery.isError
                      ? <span>Shared rates are unavailable</span>
                      : <span>Enter both rates to set your conversion</span>}
              </div>
            </div>
            <div className="convert-topline">
              <h2 className="convert-title">Quick conversion</h2>
              <span className="instant-tag"><Check size={13} /> Instant</span>
            </div>

            <label htmlFor="aed-amount" className="amount-caption">You send · <span className="currency-inline"><CountryFlag country="uae" /> AED</span></label>
            <div className="amount-entry">
              <span className="amount-prefix"><CountryFlag country="uae" /> AED</span>
              <input
                id="aed-amount"
                className="amount-input"
                type="number"
                inputMode="decimal"
                min="0"
                step="any"
                placeholder="0.00"
                value={amount}
                onChange={(event) => setAmount(event.target.value)}
                aria-invalid={Boolean(amountError)}
                data-testid="input-aed-amount"
              />
            </div>
            <div className="amount-actions">
              {amount ? (
                <button type="button" className="clear-amount" onClick={() => setAmount('')} data-testid="button-clear-amount">
                  Clear amount
                </button>
              ) : null}
            </div>

            <div className="result-divider" />
            <div className="result-caption">They receive · <span className="currency-inline"><CountryFlag country="india" /> INR</span></div>
            <div className="result-line" aria-live="polite">
              <CountryFlag country="india" />
              <span className="result-currency">₹</span>
              {converted !== null
                ? <output className="result-value" data-testid="text-converted-inr">{formatIndian(converted)}</output>
                : <span className="result-placeholder" data-testid="text-converted-inr-placeholder">— — —</span>}
            </div>
            <div className="result-note" data-testid="text-conversion-status">{resultMessage}</div>
          </div>
        </section>

        <section className="trust-strip" aria-label="Rate and privacy details">
          <div className="trust-copy">
            <span className="trust-icon"><ShieldCheck size={17} /></span>
            <span><strong>Shared reference rates</strong>Everyone sees the latest rate saved by the editor. PaySnap does not fetch live prices.</span>
          </div>
          <div className="local-note" data-testid="text-shared-rates-note">
            <Check size={13} />
            Rates shared with everyone
          </div>
        </section>

        <footer className="page-footer">
          <span>PaySnap</span> · Your money, made clear
        </footer>
      </main>
    </div>
  );
}

function App() {
  const [queryClient] = useState(() => new QueryClient());
  return (
    <QueryClientProvider client={queryClient}>
      <Home />
    </QueryClientProvider>
  );
}

export default App;
